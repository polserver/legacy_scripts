Last Updated - 10:58AM January 4th, 2010
By MuadDib
 
Icrontc Scriptbase, supplied by MuadDib and used 
originally on the shard Icrontic when he was a dev 
there and first learning eScript.

Slowly being converted from 095 to 099.