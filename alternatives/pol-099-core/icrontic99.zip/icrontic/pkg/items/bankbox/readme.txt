Well not a lot to say here, just add the pkg and make sure you have /scripts/util/bank.inc.  After that just start .creating the stuff.

Also note this is NOT a completely original pkg.  I got the pkg.cfg and itemdesc.cfg for a nearly identical pkg, but no source.  So this is a clone of the original pkg.

The pkg.cfg of the original pkg is as follows:

Enabled		0
Name		bankbox
Maintainer	imtcb
Email		imtcb@yahoo.com
