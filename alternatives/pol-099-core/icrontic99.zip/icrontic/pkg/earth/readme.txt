*********************************************
*
*
* Druid Spell Book Package 0.1
*
* Author: Wicked Angel
*
*
*********************************************
Pretty easy to get this to work ...

1) Unzip all files into a dir (ie: pol\pkg\opt\druid)
2) Edit inscription.src and inscription.cfg and APPEND them to the ones in
   pol\pkg\std\inscription
3) edit SPELLS.CFG and change what REAGS you want to use, if any.
4) Restart server and you are off to go!!!!

I'd like to first point out that this is my FIRST attempt at pol scripting, as
well as making a "package" ... so if you have any trouble, you know where to
flame me =)

Also, I used Sigismund's Necro package as a "foundation" to this package ..
the rest I added myself (spell effects and the like) ... So again ... Thanks
Sigismund =) ...


Hope you guys enjoy !!!!

Wicked Angel
