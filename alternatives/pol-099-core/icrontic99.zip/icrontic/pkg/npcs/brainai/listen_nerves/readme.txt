
Core required   : 094
Distro required : 094

This is a simple listen nerve to allow an NPC to reply to speech per the 094 speechgroup files.  It contains some fixes to 094's speech response routines as well and slight enhancements.  All you need to do to install it is put it in your listen_nerves subdirectory, compile it, and make the appropriate entry in your npcdesc.cfg file for the brain to use it as a nerve.

It requires the AI_Brain package by Austin of course, and a degree of understanding of that package to install and get working properly.  So if you haven't gotten the AI_Brain package yet, do so, and get it running properly and get an understanding of it before you try to install this nerve in anything.

