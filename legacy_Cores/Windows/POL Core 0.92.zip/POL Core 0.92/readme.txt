Penultima Online (POL)
Copyright (C) 1993-1999 Eric N. Swanson
Do not distribute this package

THIS PACKAGE IS PROVIDED "AS IS" AND WITHOUT ANY EXPRESS OR 
IMPLIED WARRANTIES, INCLUDING, WITHOUT LIMITATION, THE IMPLIED 
WARRANTIES OF MERCHANTIBILITY AND FITNESS FOR A PARTICULAR PURPOSE.

NOTE:
=====
Make SURE the utility you are using to unzip POL supports long filenames (like WINZIP)!
If any of the filenames are truncated the server will now start.

QUICK START:
============
 SERVER
 ------
  In POL.CFG, Edit the UoDatafileRoot= line to match your UO directory.

  (Most don't need to do this, as POL detects your IP automatically)
  in CONFIG\SERVERS.CFG, Edit the first entry's IP address to match your own.

  You may want to edit DATA\ACCOUNTS.DAT to create accounts

  From this directory, run POL.EXE

 CLIENT
 ------    
  in your UO\LOGIN.CFG, Change all LoginServer entries to match your 
    IP address, Port 5003.

  Run CLIENT.EXE    
