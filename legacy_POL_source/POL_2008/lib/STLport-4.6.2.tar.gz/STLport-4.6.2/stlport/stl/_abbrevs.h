/*
 *
 * Copyright (c) 1999 
 * Boris Fomitchev
 *
 * This material is provided "as is", with absolutely no warranty expressed
 * or implied. Any use is at your own risk.
 *
 * Permission to use or copy this software for any purpose is hereby granted 
 * without fee, provided the above notices are retained on all copies.
 * Permission to modify the code and to distribute modified code is granted,
 * provided the above notices are retained, and a notice that the code was
 * modified is included with the above copyright notice.
 *
 */

/* NOTE: This is an internal header file, included by other STL headers.
 *   You should not attempt to use it directly.
 */

#ifndef _STLP_INTERNAL_ABBREVS_H
# define _STLP_INTERNAL_ABBREVS_H

// ugliness is intentional - to reduce conflicts
#  define input_iterator_tag             _In__ItT
#  define output_iterator_tag            _Ou__ItT
#  define bidirectional_iterator_tag     _Bd__ItT
#  define random_access_iterator_tag     _Ra__ItT
#  define input_iterator                 _In__It
#  define output_iterator                _Ou__It
#  define bidirectional_iterator         _Bd__It
#  define random_access_iterator         _Ra__It
#  define reverse_bidirectional_iterator _rBd__It
#  define reverse_iterator               _r__It
#  define back_insert_iterator           _bI__It
#  define front_insert_iterator          _fI__It
#  define raw_storage_iterator           _rS__It
#  define _Const_traits _C_Tr
#  define _Nonconst_traits _N_Tr

// ugliness is intentional - to reduce conflicts probability
#  define __malloc_alloc   M__A
#  define __node_alloc     D__A
#  define __new_alloc      N__A
#  define __debug_alloc    G__A

#  define __deque_iterator         _dQ__It
#  define _Buf_traits              _dQ__BTr
#  define _Deque_iterator          _Dq__It

#  define _Select1st _S1st
#  define _Select2nd _S2nd

#  define _Hashtable_iterator         _hT__It
#  define _Hashtable_const_iterator   _hT__cIt
#  define _Hashtable_node             _hT__N
#  define _Hashtable_base             _hT__B
#  define _Ht_iterator _Ht_It

#  define __list_iterator         _L__It
#  define __slist_iterator         _SL__It

#  define _Rb_tree_node_base       _rbT__NB
#  define _Rb_tree_node            _rbT__N
#  define _Rb_base_iterator        _rbTB__It
#  define _Rb_tree_base_iterator   _rbT__It
#  define _Rb_tree_base            _rbT__B

#endif

