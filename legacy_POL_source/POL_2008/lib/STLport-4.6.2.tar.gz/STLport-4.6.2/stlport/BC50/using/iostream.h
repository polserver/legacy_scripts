using _STLP_VENDOR_STD::cin;
using _STLP_VENDOR_STD::cout;
using _STLP_VENDOR_STD::cerr;
using _STLP_VENDOR_STD::clog;

# if ! defined (_STLP_NO_WIDE_STREAMS)
using _STLP_VENDOR_STD::wcin;
using _STLP_VENDOR_STD::wcout;
using _STLP_VENDOR_STD::wcerr;
using _STLP_VENDOR_STD::wclog;
# endif
