using _STLP_NEW_IO_NAMESPACE::setiosflags;
using _STLP_NEW_IO_NAMESPACE::resetiosflags;
using _STLP_NEW_IO_NAMESPACE::setbase;
using _STLP_NEW_IO_NAMESPACE::setfill;
using _STLP_NEW_IO_NAMESPACE::setprecision;
using _STLP_NEW_IO_NAMESPACE::setw;
