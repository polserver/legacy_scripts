// #define __BUILDING_STLPORT 1
#define _STLP_OWN_IOSTREAMS 1
// #define _DLL
#define _WIN32
