<head>
<META HTTP-EQUIV=Refresh CONTENT="300; URL=<?php print $PHP_SELF ?>">
<LINK REL='stylesheet' TYPE='text/css' HREF='stylesheet.css'>
</head>
<html>

<body topmargin="0" bgcolor=#212121>
<center>
<font color=#FFCF00><b><u>Ultima Online:</b></u></font><br>
<?php 
error_reporting(0); //If your server is offline, this will keep it from printing an error. 
    $fp = fsockopen("mytharria.dyndns.org", 5003, $errno, $errstr, 1 ); 
    if (!$fp) { 
    echo "<font color=#FFFFFF>Server:</font> <font color=#FF0000><b>Offline</b></font>";
    } 
    else { 
    echo "<font color=#FFFFFF>Server:</font> <font color=#00CC33><b>Online</b></font><br>";    
    echo("<iframe src='http://mytharria.dyndns.org:4040/onlineplayercount.ecl' name='Server Status'width='85' height='18' frameborder='NO' border='0' framespacing='0' scrolling='NO' noresize style='position:absolute; top:36px; left:40px'></iframe>");
    fclose($fp); 
    } 
?>
</center>

