to install this package just drop it into the pkg\opt folder, recompile, enable, and restart.. 

this package requires at least the Pol 90 core.

optional: add the addgoloc.src/ecl and go.src/ecl to the scripts\textcmd\seer 
directory and the golocs.cfg to the pol\config directory...