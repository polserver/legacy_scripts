DelayFixes v1.0
===============
Written by: Jaleem

This package contains only temporary fixes for the bug caused by the massive
delay. It's assumed that this package will be removed as soon as possible.

