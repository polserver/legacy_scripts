/**
 * Insert the type's description here.
 * Creation date: (12/03/2001 16:47:39)
 * @author:
 */
public class Logger {
	public final static java.lang.String MYLOG = "logger.log";
	public final static String VERSION = "POLLogger02";
	private final static java.text.SimpleDateFormat formatter = new java.text.SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
	private final static java.util.Date dateobj = new java.util.Date();
/**
 * Logger constructor comment.
 */
public Logger() {
	super();
}
/**
 * Starts the application.
 * @param args an array of command-line arguments
 */
public static void main(java.lang.String[] args) throws java.net.UnknownHostException {
	if(args.length!=2) {
		System.err.println("USE: java Logger hostname port");
		System.exit(1);
	}
	java.net.InetAddress ineta=java.net.InetAddress.getByName(args[0]);
	int port=(new Integer(args[1])).intValue();
	pol.AuxConnection aux=null;
	pol.Variable var, tmp1, tmp2;
	while(true) {
		while(aux==null) {
			try {
				aux=new pol.AuxConnection(ineta, port);
				var=aux.receive();
				if((var instanceof pol.VarString)&&((pol.VarString)var).getValue().compareTo(VERSION)==0)
					writeLog(MYLOG, "Connected on "+ineta+":"+port);
				else {
					aux.close();
					aux=null;
				}
			} catch(Exception e) {
				aux=null;
				writeLog(MYLOG, "Server not found, waiting 30 seconds");
				try {
					Thread.sleep(30000);
				} catch(InterruptedException e2) {
				}
			}
		}
		try {
			var=aux.receive();
			//writeLog(MYLOG, "Received packet "+var);
			if(var instanceof pol.VarArray) {
				tmp1=((pol.VarArray)var).getValue(1);
				tmp2=((pol.VarArray)var).getValue(2);
				if((tmp1 instanceof pol.VarString) && (tmp2 instanceof pol.VarArray)) {
					pol.VarArray arr=(pol.VarArray)tmp2;
					java.io.FileWriter fw=openLog(((pol.VarString)tmp1).getValue());
					int i, l=arr.getSize();
					pol.Variable v;
					//writeLog(MYLOG, "Internal array is "+l);
					for(i=1; i<=l; i++) {
						v=arr.getValue(i);
						if(v instanceof pol.VarString)
							writeLog(fw, ((pol.VarString)v).getValue());
					}
					fw.close();
				} else
					writeLog(MYLOG, "Received unexpected "+var);
			}
		} catch (java.io.IOException e) {
			var=null;
			aux=null;
			writeLog(MYLOG, "Connection closed");
		}
	}
}
/**
 * Insert the method's description here.
 * Creation date: (12/03/2001 17:17:05)
 * @param filename java.lang.String
 * @param logline java.lang.String
 */
private static java.io.FileWriter openLog(String filename) {
	java.io.FileWriter fw;
	try {
		fw=new java.io.FileWriter(filename, true);
	} catch(java.io.IOException e) {
		fw=null;
	}
	return(fw);
}
/**
 * Insert the method's description here.
 * Creation date: (12/03/2001 17:17:05)
 * @param filename java.lang.String
 * @param logline java.lang.String
 */
private static void writeLog(java.io.FileWriter fw, String logline) {
	if (fw != null) {
		java.util.Date d;
		try {
			dateobj.setTime(System.currentTimeMillis());
			fw.write(formatter.format(dateobj) + ' ' + logline + '\n');
		} catch (java.io.IOException e) {
		}
	}
}
/**
 * Insert the method's description here.
 * Creation date: (12/03/2001 17:17:05)
 * @param filename java.lang.String
 * @param logline java.lang.String
 */
private static void writeLog(String filename, String logline) {
	java.io.FileWriter fw=openLog(filename);
	if (fw != null) {
		java.util.Date d;
		try {
			dateobj.setTime(System.currentTimeMillis());
			fw.write(formatter.format(dateobj) + ' ' + logline + '\n');
			fw.close();
		} catch (java.io.IOException e) {
		}
	}
}
}
