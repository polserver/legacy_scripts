package pol;

/**
 * Insert the type's description here.
 * Creation date: (12/03/2001 09:41:48)
 * @author: Lapo Luchini <lapo@lapo.it>
 */

/*
Packet format

int:
i1234

float
r1.353e-3 //use strtod

string:
if on the begining
S:absbsbs
if on the middle
sxx:djd
xx is string size

array:
axx:ddddd
xx is the size
object then are added sequencialy.
when an offset holds no object i gots a 'x'
like:
var i:= {1};
i[4] :=2;
packet it is:
a4:i1xxi2

uninit
u (without ':')

struct/dictionary/error (d,t,e)
format
(d,t,e)xx: data
xx is the number of pair
data is composed of xx pair of data sequentialy
like:
var i:= dictionary;
i[1]:=2;
i["a"]:=2.4;
packed:
d2:i1i2s1:ar2.4

thanks to Louds for the infos!
*/
public abstract class Variable {
	public static class ParserState {
		char[] str;
		int pos;
	}
	public static class POLParserException extends RuntimeException {
		POLParserException(ParserState ps) {
			super("\""+String.copyValueOf(ps.str, 0, ps.pos)+"<<HERE>>"+String.copyValueOf(ps.str, ps.pos, ps.str.length-ps.pos)+"\"");
		}
		POLParserException(ParserState ps, String s) {
			super(s+" \""+String.copyValueOf(ps.str, 0, ps.pos)+"<<HERE>>"+String.copyValueOf(ps.str, ps.pos, ps.str.length-ps.pos)+"\"");
		}
	}
/**
 * Insert the method's description here.
 * Creation date: (12/03/2001 15:39:25)
 * @return java.lang.String
 */
public abstract String getPOLformat();
/**
 * Insert the method's description here.
 * Creation date: (12/03/2001 15:53:57)
 * @return pol.Variable
 * @param s java.lang.String
 */
public final static Variable parsePOLformat(String s) {
	ParserState ps=new ParserState();
	int len=s.length();
	ps.str=new char[len];
	s.getChars(0, len, ps.str, 0);
	ps.pos=0;
	return (Variable.parsePOLformatGeneric(ps));
}
/**
 * Insert the method's description here.
 * Creation date: (12/03/2001 15:53:57)
 * @return pol.Variable
 * @param s java.lang.String
 */
public static Variable parsePOLformatGeneric(ParserState ps) {
	switch(ps.str[ps.pos]) {
		case 'i': return(VarInteger.parsePOLformat(ps));
		case 'r': return(VarReal.parsePOLformat(ps));
		case 'S':
		case 's': return(VarString.parsePOLformat(ps));
		case 'a': return(VarArray.parsePOLformat(ps));
		case 'u': return(VarUninitialized.parsePOLformat(ps));
		case 'd': 
		case 't': 
		case 'e': return(VarStruct.parsePOLformat(ps));
		 default: throw new POLParserException(ps, "Type not recognized");;
	}
}
/**
 * Insert the method's description here.
 * Creation date: (13/03/2001 18:43:31)
 * @return java.lang.String
 */
public String toString() {
	return(getPOLformat());
}
}
