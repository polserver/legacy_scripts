package pol;

/**
 * Insert the type's description here.
 * Creation date: (12/03/2001 16:20:23)
 * @author: Lapo Luchini <lapo@lapo.it>
 */
public final class VarString extends Variable {
	private String value;
/**
 * VarString constructor comment.
 */
public VarString(String value) {
	this.value=value;
}
/**
 * getPOLformat method comment.
 */
public String getPOLformat() {
	StringBuffer u=new StringBuffer();
	u.append('S');
	u.append(value.length());
	u.append(':');
	u.append(value);
	return(u.toString());
}
/**
 * Insert the method's description here.
 * Creation date: (12/03/2001 16:21:56)
 * @return java.lang.String
 */
public java.lang.String getValue() {
	return value;
}
/**
 * Insert the method's description here.
 * Creation date: (12/03/2001 15:53:57)
 * @return pol.Variable
 * @param s java.lang.String
 */
public static Variable parsePOLformat(ParserState ps) {
	int value=0;
	if(ps.str[ps.pos]=='s')
		value=ps.str.length-(++ps.pos);
	else if(ps.str[ps.pos]=='S') {
		ps.pos++;
		while(Character.isDigit(ps.str[ps.pos]))
			value=value*10+Character.getNumericValue(ps.str[ps.pos++]);
		if(ps.str[ps.pos]!=':')
			throw new POLParserException(ps, "POL's string values must have a ':'");
		else
			ps.pos++;
	} else
		throw new POLParserException(ps, "POL's string values must begin with 's'");
	ps.pos+=value;
	return(new VarString(String.copyValueOf(ps.str, ps.pos-value, value)));
}
/**
 * Insert the method's description here.
 * Creation date: (12/03/2001 16:21:56)
 * @param newValue java.lang.String
 */
public void setValue(java.lang.String newValue) {
	value = newValue;
}
}
