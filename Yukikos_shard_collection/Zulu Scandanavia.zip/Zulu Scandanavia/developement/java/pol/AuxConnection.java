package pol;

/**
 * Insert the type's description here.
 * Creation date: (12/03/2001 09:49:37)
 * @author: Lapo Luchini <lapo@lapo.it>
 */
public class AuxConnection {
	private java.net.Socket sock;
	private boolean connected;
	private java.io.BufferedReader br;
	private java.io.BufferedWriter bw;
/**
 * Connection constructor comment.
 */
public AuxConnection(java.net.InetAddress host, int port) throws java.io.IOException {
	try {
		sock=new java.net.Socket(host, port);
		br=new java.io.BufferedReader(new java.io.InputStreamReader(sock.getInputStream()));
		bw=new java.io.BufferedWriter(new java.io.OutputStreamWriter(sock.getOutputStream()));
		connected=true;
	} catch(java.io.IOException e) {
		sock=null;
		br=null;
		bw=null;
		connected=false;
	}
}
/**
 * Insert the method's description here.
 * Creation date: (12/03/2001 17:02:00)
 */
public void close() throws java.io.IOException {
	bw.close();
	br.close();
	sock.close();
}
/**
 * Insert the method's description here.
 * Creation date: (12/03/2001 16:45:17)
 * @return pol.Variable
 */
public Variable receive() throws java.io.IOException {
	return(Variable.parsePOLformat(br.readLine()));
}
/**
 * Insert the method's description here.
 * Creation date: (12/03/2001 09:54:07)
 * @param var uo.Variable
 */
public void send(Variable var) throws java.io.IOException {
	bw.write(var.getPOLformat());
	bw.flush();
}
}
