package pol;

/**
 * Insert the type's description here.
 * Creation date: (12/03/2001 15:45:50)
 * @author: Lapo Luchini <lapo@lapo.it>
 */
public final class VarInteger extends Variable {
	private int value;
/**
 * VarInteger constructor comment.
 */
public VarInteger(int value) {
	this.value=value;
}
/**
 * getPOLformat method comment.
 */
public String getPOLformat() {
	return("i"+value);
}
/**
 * Insert the method's description here.
 * Creation date: (12/03/2001 15:52:55)
 * @return int
 */
public int getValue() {
	return value;
}
/**
 * Insert the method's description here.
 * Creation date: (12/03/2001 15:53:57)
 * @return pol.Variable
 * @param s java.lang.String
 */
public static Variable parsePOLformat(ParserState ps) {
	int value=0;
	boolean neg=false;
	if(ps.str[ps.pos++]!='i')
		throw new POLParserException(ps, "POL's integer values must begin with 'i'");
	if(ps.str[ps.pos]=='-') {
		neg=true;
		ps.pos++;
	}
	while((ps.pos<ps.str.length)&&Character.isDigit(ps.str[ps.pos]))
		value=value*10+Character.getNumericValue(ps.str[ps.pos++]);
	return(new VarInteger(neg ? -value : +value));
}
/**
 * Insert the method's description here.
 * Creation date: (12/03/2001 15:52:55)
 * @param newValue int
 */
public void setValue(int newValue) {
	value = newValue;
}
}
