Original Script by "Someone who posted on 092 scripts group"
Modified by Kardall
Re-Release Date - Dec 1st 2002

[- Notes -]

Original 092 Script fixed to run with a DEFAULT 094 installation.
All you should have to do is extract this into your
pol directory and compile all necessary scripts...

I extracted my POL files into C:\POL and that's how these are stored.
please move them into the correct folder if your pol root folder is different...

for example:

if you used c:\pol094comp\
move all files to their folders using that, so it'd be:

\pol094comp\pkg\shrink
\pol094comp\pkg\shrink\textcmd\seer\

for the two sets of files...

Please Note :: I had to change the items for all of these (took me a while) so that
they worked... I grabbed a rather large chunk of Item #'s that aren't taken by default
and used them (Refer to your own objtype.txt in POL Dir to make sure that the same
numbers can be used).

I cannot be held responsible for anything that goes wrong on your shard because
you used this script. I just fixed it to the way it compiles correctly under POL094.
Don't come running to me if it crashes your shard or anything like that. I didn't
really modify the code "THAT" much...