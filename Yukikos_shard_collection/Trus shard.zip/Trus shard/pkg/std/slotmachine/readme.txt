place this in
the std/slotmachine folder