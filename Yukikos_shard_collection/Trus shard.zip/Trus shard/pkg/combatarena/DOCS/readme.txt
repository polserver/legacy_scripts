Arena system by Austin Heilman
Email: Austin@tsse.net
__________________________________________________________
About:

Thanks to Black-Knight on #pol for testing how this interfaces
with other POL shards.

This is an arena package designed with concepts similar to the
poison watcher. The arena's backbone is a method script on the
arena boards. The idea behind is it to allow arenas to be 
designed with an 'engine' feel to them. As such, the various
types of arena combat are referred to as 'arena engines'.

These engines are what drive the arenas when they are in use.
Currently the engines I have developed are
PvM    - Player Versus Monster
PvP    - Player Versus Player
FFA    - Free For All
TB     - Team Battle

PvM involves 1 player fighting 1 randomly chosen monster
based on the level the player selected.

PvP involves 2 players. They combat to the death. The one
who does not die, is the winner.

FFA involves as many players as the person setting the arena
up selects. The winner is the very last man standing.

TB works much like FFA does but instead of the last man 
standing, it is the last team standing.

In the future I may also add in a TvM (Team Versus Monster(s)).



The board is set up so that when a player double clicks it,
he or she will be given a gump with the various styles of
arena combat available based on the information in 
arenamodes.cfg The arena will only allow one person to setup
an arena at a time and will prevent anyone else from setting
up an arena while a tournament is running. Anyone who is 
killed in a tournament is immediately sent to the exit point.
Any items that are inside the arena and movable are always
placed at the exit point when it runs an interference check.
The arena will also bounce people out of it that are not part
of the tournament.
__________________________________________________________
Additional Notes:
Things you may want to consider, but I will not provide 
support with how to do it.

* You may want to disable combat skill gain on anyone who has
  the #arena cprop. I will not provide support on doing this
  because of the many, many ways it differs between shards.

* You may want to charge players gold or something to use the
  arena. The best place to do this is right before starting a
  setup script. You would want to do this on line 54 after the
  else statement under the system message "Cancelled".

  The easiest way to do this is to say
  ----8<-----------
    if ( ConsumeSubstance(who.backpack, GetObjTypeByName("GoldCoin"), 50) )
           ... code to start the setup script and engine script
    else
           SendSysMessage(who, "You do not have 50 gold");
    endif
  ---->8-----------
  then start the 
__________________________________________________________
Installation:

Extract into x:\xPOLx\pkg\Arena

You will most likely need to edit the include paths in the
scripts to correctly point to your gumps.inc
For most setups using the standard pol distribution it will
be "../pkg/foundations/gumps/gumps"

Script edits to make:

--=[ death.src ]=----

include "../pkg/arena/includes/events";

if ( GetObjProperty(corpse, "#arena") )
	var pid := GetObjProperty(corpse, "#arena");
	var process := GetProcess(pid);
	var temp := struct;
	temp.+type := REMOVE_CONTESTANT;
	temp.+serial := GetObjProperty(corpse, "#ArenaSerial");

	process.SendEvent(temp);

	DestroyItem(corpse);
	return;
endif

--=[ chardeath.src ]=----

include "../pkg/arena/includes/events";

if ( GetObjProperty(ghost, "#arena") )
	var pid := GetObjProperty(ghost, "#arena");
	var process := GetProcess(pid);
	var temp := struct;
	temp.+type := REMOVE_CONTESTANT;
	temp.+serial := ghost.serial;
	temp.+corpse := corpse;

	process.SendEvent(temp);
	return;
endif

__________________________________________________________

History

-=[ March 06, 2003 ]=-
Package Created




