Name conjuration
Version 0.1
Requires gumps 2.1
Requires raceclasssys 0.1
Requires hirelings 0.1
Requires resnpc 0.1
Maintainer M.o.E
Email m.o.e@moe99.cjb.net

These sripts are published without any warranty, they are not completely tested so there could (will)
be some bugs in them. If you find a bug, fix it and send the fix to me, please. If you can't fix the
bug send it to me (m.o.e@moe99.cjb.net) with exact desciptions of the bug and how to reproduce it
(with example code). If my time permits, I'll then try to fix it.

Intro:
The conjuration package gives the character the possibility to conjure every NPC on the shard (if
the char has sufficient skill to do that) and make them work for the char. First the char has to
inscribe the information of a creature to a blank scroll, then insert the conjrescroll into the
conjurebook and then the char can conjure the NPC directly (the existing NPC on the shard) or from
the conjurebook or -scroll create a new one.
Now the conjured NPC will act like a tamed animal with some additional possibilities:
The NPC can work for you (mining, luberjacking,...) like hirelings (see also my hirelings pkg) if
the NPC has the skills to do that.

Command list for conjured NPCs:
Standard:
kill,attack,fight
stop
come
follow
transfer
release
guard
fetch
drop
speak

Extra:
mount,ride:     Mount a horse, ostard,...
dismount:       Dismount a horse, ...
work:           Get the Stats and Skills of the NPC and let it work for you.
remove items:   Removes all items from the NPC backpack.
wear:           Equip a weapon or armor.
undress:        Undress all equipt items from NPC
camp:           Guards the area where it stands.
help:           Search for enemies.
heal,cure:      Heal or cure someone (with bandages or spells -> if healernpc)
resurrect me:   Resurrects master if it is a healernpc
quote:          Give the NPC a quote it should say to other PCs when you are offline.
training:       Learn from an merchant NPC (says: vendor train)
training <skillname>: Learn from an merchant NPC (says: vendor train <skillname>)
pay <amount>:   Pay merchant NPC for what your NPC have learned (gives <amount> of gold to the
                merchant NPC, if it is in the backpack of your NPC.
move:           Moves a little away from you (e.g. if you are blocked)
throw:          Throws exlosion potion to opponent if there is one in the backpack of your NPC.
loot:           Loot corpse near the NPC.
autoloot:       Autoloot corpse the NPC has killed (e.g. during the camp mode)
carve:          Carve corpse near NPC.
wash:           Wash the bloody bandages in the NPC backpack.
help:           Search and fight enemy.
brb:            Clear event queue
stuck:          Try to free a stuck NPC

You have to feed your NPC make them stay with you more time.
And you can train the human ones on dummies...

For conjuring creatures you need three skills:
Animal Lore: To aquiring information about the creature.
Magery: To conjure the creature.
Inscription: To inscribe a blank scroll with the creature inforation.

So it isn't easy to become a GM Conjuror.
You can only conjure a creature (exiting NPC) if you have already the information about this
creature in your conjurebook.
And the conjuror will be flagged as criminal and lose a lot of karma if he/she tries to conjure an
exitsting 'good' (pos. karma) NPC. This is not the case if it was conjured from a scroll or
conjurebook before.

Files in the package:
pkg.cfg (pkg/opt/conjuration): Package config file.

ctrl_reg.src (pkg/opt/conjuration): Script to register this package with the control package.

itemdesc.cfg (pkg/opt/conjuration): Definition of the conjure items.

conjurebook.src (pkg/opt/conjuration): Script for the conjurebook gump.

scrollcaninsert.src (pkg/opt/conjuration): Checks if the conjurescroll can be inserted to the book.

scrolloninsert.src (pkg/opt/conjuration): Checks if the conjurescroll can be inserted to the book.

conjuretoscroll.src (pkg/opt/conjuration): Inscribes the information of a creature to a conjurescroll.

conjurefkts.inc (pkg/opt/conjuration): Some common functions.

scroll.src (pkg/opt/conjuration): Script to conjure a creature from a scroll or conjurebook.

conjured.src (pkg/opt/conjuration): NPC AI for the conjured creatures.

supportpc.inc (scripts/include): Needed by conjured.src.

creaturefkts.inc (scripts/include): Needed by supportpc.inc.

commonfkts.inc (scripts/include): Needed by creaturefkts.inc.

npctrain.inc (scripts/include): Needed by creaturefkts.inc to train NPCs on dummys and archery butt.

From other pkgs:
karmafame.inc (scripts/include): Needed by creaturefkts.inc. My Karma/Fame-System to check if the
near NPCs are bad or good and see above.

resnpc.inc (scripts/include): Needed by supportpc.inc to create the rune of memory in the NPC
backpack for possible later resurrection. (see my resnpc package)

Feedback:

If you have questions or bugfixes, please send them to m.o.e@moe99.cjb.net
Also positiv feedback are welcome.

