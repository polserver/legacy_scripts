name shapechange
enabled 1
Version 0.1
Requires raceclasssys 0.1
Requires awardsystem 0.1
Maintainer M.o.E
Email m.o.e@moe99.cjb.net

These sripts are published without any warranty, they are not completely tested so there could (will)
be some bugs in them. If you find a bug, fix it and send the fix to me, please. If you can't fix the
bug send it to me (m.o.e@moe99.cjb.net) with exact desciptions of the bug and how to reproduce it
(with example code). If my time permits, I'll then try to fix it.

Intro:
Well some time ago I found a shapechange pkg in the files section of the pol scriptforum, but I
thought what will be your motivation to reach the skill to change form to a dragon if the only thing
that changes is the graphic and nothing else? As dragon you aren't stronger nor more intelligent you
simply keep all your skills and stats.

So I decided to change this frustrating circumstances a little bit. With this shapechange pkg, when
changeing form you also get all the skills and stats of the animal from the npctemplate. If the
animal has spells in the npctemplate you receive a temp. spellbook with this spells and if the
animal is a firebreather you will receive the temp posibility to firebreath with an award in your
awardbook (see my awardsystem pkg). Now I guess there is little bit more motivation to get GM
shapechanger.

Files in the package:
pkg.cfg (pkg/opt/shapechange): Package config file.

ctrl_reg.src (pkg/opt/shapechange): Script to register this package with the control package.

itemdesc.cfg (pkg/opt/shapechange): Definition of the temp. spellbook.

shapechangebook.src (pkg/opt/shapechange): Script for th temp. spellbook gump.

creaturebook.inc (scripts/include): Used from shapechangebook.src.

pccast.inc (scripts/include): Used from creaturebook.inc to cast from temp. spellbook.

shapechange.src (pkg/opt/shapechange): Script used to shapechange to a new form.

shapechangelive.src (pkg/opt/shapechange): Script to start the shapechange live cycle.

shapechangeing.inc (pkg/opt/shapechange): Main shapechange functions. (The heart of the pkg)

shapechange.cfg (pkg/opt/shapechange): Config file where you put all the animals you will permit to
change to.

dummy.src (pkg/opt/shapechange): Simply does nothing. (Script for all skills when in animal form)

logofftest.src (scripts/misc): Includes part for this pkg to prevent problems with restarting the
server when the char logged out in e.g. animal form.

logon.src (scripts/misc): Includes part for this pkg to prevent problems with restarting the server
when the char logged out in e.g. animal form and starts the live cycle for that form.

Feedback:

If you have questions or bugfixes, please send them to m.o.e@moe99.cjb.net
Also positiv feedback are welcome.

