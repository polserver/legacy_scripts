
UPDATE TO THIS DOCUMENTATION : 

Since the time of this writing, the POL developers have come down pretty strongly against the use or support of Folko's packet hooks.  At the time I originally wrote this, the sentiment seemed more apathetic to me, so I went ahead and put in support for it for completeness.  Also, it is admittedly through Folko's package that I did much of the scripting for this package, and so through that only came to realize it could also be done outside of packet hooks.

Given the POL developers stance however, I felt I could not distribute this widely in good faith unless I removed support for Folko's packet hooks.  So, such is done.  When/if packet hooks are put into POL officially, I should be supporting it.

The documentation below has not been updated to this effect, but you can consider that you have automatically taken the option to install a non-packet hooking system, as the packet hook support files have been removed from this distribution.


----------------------------------------------------------


This package is intended for POL 094.  Furthermore, it is assumed you are operating on the standard distribution.  If you have significantly modified portions of your distribution, the instructions contained herein, and the scripts provided may or may not work for you.

Furthermore, this entire package is at your own risk.  I have tested it on my shard, but it is not a large shard, and not up 24/7.  If you find significant bugs, I welcome notification of such, but I am not going to teach you how to install this package into your shard.  Suffice it to say, if you are not familiar with scripting, this may be a package to avoid.

I have purposefully set the pkg.cfg to disabled and likewise purposefully NOT provided compiled versions.  If it is beyond your ability to enable a package or compile these scripts, then you should NOT be installing them on your shard, period.

Some of these scripts require substantial modification to pre-existing distibution code.  I will provide instruction as to what needs to be modified and how, but you are hereby advised to MAKE BACKUPS OF EVERYTHING YOU MODIFY!!!  I cannot stress this enough.  If you make a modification, even if you followed my instructions to the T, and it doesn't work, I will not be crying for you when you tell me you didn't keep a backup, nor will I be helping you restore your shard to it's prior condition.

And to add to all of that, I have not the slightest clue how well or poorly this package will react with clients of an older nature than roughly 3.0.x's.  If you have players using 1.24.6 on your shard, or even 2.0.0 for all I know, it is very possible that players might be able to crash other players with older clients by using the commands provided here to have the server send packets those clients don't understand(such as the party system invite packet).  Do not come to me with problems with these older clients.  I am telling you now, if you support them, it is doubly, triply, AT YOUR OWN RISK.

If all of that wasn't enough of a disclaimer to scare off the newbies looking at putting this in without knowing what they are doing, read the following words very carefully.


          >>>>>>>>>>  USE THIS AT YOUR OWN RISK.  <<<<<<<<<<<<<<


That said, if you are still interested in installing some or all of this package, I will do my best to explain how it is done.

First, an explanation of what this package is attempting to provide.

The package provides three areas of functionality.

A) Skill Locks
B) Profiles
C) Party System

I did my best to support, as much as possible, Folko's packet hooking package in regards to all three of these.  However, as a general rule, I would suggest to people to stay with non-hacked versions of POL.  If/when POL officially supports packet hooking, I will be modifying these packages to use that support and will likely take out the hooking provided by Folko.  Such is only provided for completeness and should not be seen as a recommendation by me to you that you use his packet hook reversed server.

All of the above packages are however supported to the best of my ability outside of what packet hooking provides.  What does this mean?  It means you don't NEED Folko's packet hook reversed server to use this package.  Things will be a little less intuitive, and there will be a definate "POL flavor" to the way they're done, but they will work just fine.

As such, the following files may be deleted from this packageif you are not intending to use Folko's packet hooks :

skilllock.src
refreshlocks.src
charprofile.src
partysystem.src
doubleclick.src

Notice I didn't list any INC files, you should not delete any of those, they are used by multiple files supporting both systems.

If you are using Folko's packet hooks and wish to remove the non-packet hook support files, you may do so as well, although, for the most part, having both ways to access the same systems will not be a problem if you have Folko's hooks.

The following files may however be deleted for a purely packet hook driven package :

accept.src
add.src
decline.src
pm.src
p.src
profile.src
quit.src
remove.src

I have not found there to be problems with having both systems in place regardless of using Folko's packet hooks or not, but such is at your discretion.

Once you have decided that question and taken the appropriate action, you should place all of the files in this package in /pol/pkg/opt, preserving the directory structure provided from there.  This should create a /pol/pkg/opt/newclientsupport folder for you, largely empty, but having a textcmd folder, and a player folder within that, which provides the functionality of this package.

Once the package is in place, you should compile all the source files.  Leave the package disabled however, there is much left to do.

Note : All the following work should be done while the shard is shut down.  Also, any modifications suggested below to pre-existing files should be preceeded by BACKING UP THE FILES TO BE MODIFIED!!

Two of the three segments of this package require modification to your current distribution files.

----------------------------------------------------------

Character Profiles : 

Of the three, character Profiles is the only thing that will work completely for you right after compiling and enabling the package.

Caveats on Profiles : Currently, players can add in as long a line as POL will allow them to each of the lines in their profile.  While taking more memory than not doing so, it doesn't seem to have any other real impact, so I didn't try to account for such.  If you wish to, and are capable, you may wish to limit the line length size saved to the profile array.

----------------------------------------------------------

Party System :

The party system will ALMOST work completely without modification.  Where it will have troubles will be with characters logging off and reconnecting not clearing the party list as it should.  The following modifications must be made in order to account for this.

**********************************************************
In /pol/scripts/misc/logoff.src :

You need to add one include line.  Place it above the following line :

include "include/math";

The line to place above that line is : 

include "../pkg/opt/newclientsupport/textcmd/player/partysystem";

You then need to do a search for the following text in the file :

staffnotify(who);

Place the following line of code just above that line :

doRemove(who);

**********************************************************

**********************************************************
In /pol/scripts/misc/reconnect.src : 

You need to add one include line.  Place it above the following line :

program reconnect(who)

The line to place above that line is : 

include "../pkg/opt/newclientsupport/textcmd/player/partysystem";

You then need to do a search for the following text in the file :

endprogram

Place the following line of code just above that line :

updateParty(who);
**********************************************************

Congradulations, you now need to recompile those two scripts you modified.  With those modifications made, you should have a functional party system.

Note, the way Folko's package works, the / for party chat only works up to 44 characters.  Even people using Folko's package however can also use the .p command in this package to chat with longer lines, and such is what is recommended to users when they use / to chat by default.

Otherwise, for non-Folko folks, .add adds people to the party, .accept accepts an invitation, .decline declines an invitation, .p is party chat, .pm and a name(first only) or number sends a private message to that party member, .quit removes yourself from the party, .remove can be used to remove others if you are the party leader, again, by first name or number.  Once your players get used to using dot commands instead of slash, it should be easily adjusted to.

----------------------------------------------------------

Skill Locks :

Caveats : As of this writing skill locking/skill cap functionality is somewhat "broken" by use of trainers to train in skill.  If someone has maxed out their skill points, and goes to a trainer to train in skill, neither the skill locking, nor the skill cap, really kicks in, certainly not immediately.  This is the case for POL anyway, but with skill locks the problem can be exasperated.  Ie, someone can get their skills they want to 100 to be a 7xGM, and then set all their skills to up, and train in all the rest of the skills to get max trainable levels with those skills without suffering under the skill cap.  I haven't figured out an elegant way to handle this, since training presently is handled by each individual AI, and thus I leave such an undertaking to your hands.  An easy way to "fix" this, would be to simply not allow characters who are within 50 points of the skill cap  to train anything at all, but that still requires modifying each AI that trains skills to do that.

That said, so far as I can tell, the skill locking I provide works and is functional.  It does however require one very substantial modification, one so substantial that I will simply provide my replacement function for one of your attributecore functions.  You may look at what I did if you like and try to do something better, or you may simply plug it in and hope it works.  But remember, before any modifications are made, BACKUP THE AFFECTED FILES!!

All normal skill gain, so far as I can tell and have witnessed, passes through a function named CheckSkillCap.  This function is fired off when a skill cap event is fired by someone gaining a skill.  They don't actually get the skill until the cap is checked, and this is where the check is made.  As I said previously, there are ways to circumvent this check, one being through buying skill from trainers, another being various GM utilities to set your skill to whatever level you like.

In order for skill locking to work, the locks must be checked against the skills being dropped or raised to make sure all is kosher.  Furthermore, the checkskillcap function is fairly buggy in the 094 distro.  Due to a bug that ignores skills under 1.0 in skill and not placing them in the skillarray cprop, the skill cap tends to just outright ignore those points' existance until they come up to 1.0, at which poitn it tries to figure out what to do and is somewhat draconian in it's countermeasures.  If you've seen your skills suddenly drop .1 6 times in a row because you gained .1 in some minor skill, you know what I am talking about.  My solution was not to bother fixing the skillarray cprop updates, even though I believe I know where it is messing up.  I just didn't see the point in going through all the overhead of checking it and adjusting it.  I feel that it is more efficient to simply go through all the skills in one pass and work from that.  If you disagree, you are welcome to see what I did to implement the skill locking checks, and otherwise fix the problem yourself.

Furthermore, unless/until POL provides a hook to allow us to update the skill window ourselves when it is called, instead of having the server do so, you will have to use the .refreshlocks command to update it appropriately if you are using Folko's packet hooks.  If you are not using packet hooks, you don't need to worry about this command(Just use .locks).  Of course, having it available for your users won't hurt either.

So, what to do?  You need to search for the CheckSkillCap function definition, and remove it entirely from /pol/pkg/foundations/hooks/attributecore.src.  Then you need to put in it's place the following function :

function CheckSkillCap(who, ev)
  var attributeid := ev.skid;
  var priorValue;
  var theId;
  var lowerholder;
  var lockArray := GetObjProperty(who, "SkLockArray");
  
  priorValue := GetAttributeBaseValue(who, attributeid);

  if(priorValue < 1000)
    if (ev.base > priorValue)  // Adding Skill, check for lock set to up
      if ((!lockArray) || 
          (lockArray[GetSkillIdByAttributeId(attributeid) + 1] == 0))
        SetAttributeBaseValue(who, attributeid, Cint(ev.base));
      endif
    elseif (ev.base < priorValue) // Lowering Skill, check for lock set to down
      if ((lockArray != error) &&
          (lockArray[GetSkillIdByAttributeId(attributeid) + 1] == 1))
        SetAttributeBaseValue(who, attributeid, Cint(ev.base));
      endif
    endif
  endif

  if(GetAttributeBaseValue(who, attributeid) > 1000)
    priorValue := 1000;
    SetAttributeBaseValue(who, attributeid, 1000);
  endif

  var skillarray := GetObjProperty(who,"SkillArray");
  var skilltotal := 0;
  var skillval := 0;
  var check := 0;
  var loops := 0;
  var holder, newval, final;
  var base, mods, true;
  while(check == 0)
    if(loops >= 6)
      if (priorValue < GetAttributeBaseValue(who, attributeid))
        SetAttributeBaseValue(who, attributeid, priorValue);
      endif
      break;
    endif
    skilltotal := 0;
    lowerholder := -1;
    
    for (theId := 0; theID < SKILLID__HIGHEST; theID := theID + 1)
      true := GetBaseSkillBaseValue(who, theID);
      base := Cint(true - GetAttributeIntrinsicMod(who, GetAttributeIdBySkillId(theId)));
      skilltotal := skilltotal + base;
      
      if ( (base > 0) &&
           (lockarray != error) && 
           (lockarray[theId + 1] == 1) )
        lowerholder := theId;
      elseif (base > 0)
        holder := theId;
      endif
      
      if ((lowerholder >= 0) && (skilltotal > CONST_SKILLCAP))
        break;
      endif
    endfor

    if (lowerholder >=0)
      holder := lowerholder;
    endif
    
    if(skilltotal > CONST_SKILLCAP)
      newval := GetBaseSkillBaseValue(who, holder);
      final := (newval - 1);
      SetBaseSkillBaseValue(who, holder, final);
    else
      check := 1;
    endif
    loops := loops + 1;
  endwhile
  return 1;
endfunction

Once you have done so, save and recompile the file.

Once all of these steps have been complete, you should enable the package in pkg.cfg and start up your server.  You are of course free to only do a partial implementation of this package, if you already have profiles you may want to not put in the profiles provided here, if you already have skill locking you may want to not put in the locking provided here.  But regardless of what you do, such is ALL AT YOUR OWN RISK.

Good luck.